import java.io.*;
import java.sql.*;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.WebServlet;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {
 public void doPost(HttpServletRequest req,
 HttpServletResponse res) throws IOException {

  try {
   Class.forName("com.mysql.cj.jdbc.Driver");

   Connection con = DriverManager.getConnection(
   "jdbc:mysql://localhost:3306/userdb","root","password");

   PreparedStatement ps = con.prepareStatement(
   "SELECT * FROM users WHERE email=? AND password=?");

   ps.setString(1, req.getParameter("email"));
   ps.setString(2, req.getParameter("password"));

   ResultSet rs = ps.executeQuery();

   if(rs.next())
    res.getWriter().println("Login Successful");
   else
    res.getWriter().println("Invalid Email or Password");

   con.close();
  } catch(Exception e) {
   res.getWriter().println(e);
  }
 }
}
