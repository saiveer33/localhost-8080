import java.io.*;
import java.sql.*;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.WebServlet;

@WebServlet("/register")
public class RegisterServlet extends HttpServlet {
 public void doPost(HttpServletRequest req,
 HttpServletResponse res) throws IOException {

  try {
   Class.forName("com.mysql.cj.jdbc.Driver");

   Connection con = DriverManager.getConnection(
   "jdbc:mysql://localhost:3306/userdb","root","password");

   PreparedStatement ps = con.prepareStatement(
   "INSERT INTO users VALUES(?,?)");

   ps.setString(1, req.getParameter("email"));
   ps.setString(2, req.getParameter("password"));

   ps.executeUpdate();
   res.getWriter().println("Registration Successful");

   con.close();
  } catch(Exception e) {
   res.getWriter().println(e);
  }
 }
}
