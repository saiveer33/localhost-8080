REGISTRATION AND LOGIN SERVLET FILES

Files included:
1. database.sql
2. register.html
3. RegisterServlet.java
4. login.html
5. LoginServlet.java

Setup:
1. Run database.sql in MySQL.
2. In both servlet files, replace "password" in the database connection
   with your actual MySQL root password.
3. Add MySQL Connector/J and Jakarta Servlet API libraries to your project.
4. Use Apache Tomcat 10.1 or another Jakarta Servlet-compatible server.
5. Put the HTML files in the web application folder and servlet classes
   in the Java source folder.
6. The @WebServlet annotations map the forms to /register and /login.

Note:
The supplied table has only email and password columns, so the username
field in register.html is not stored. Passwords are stored as plain text
for this simple classroom example only; real applications should hash them.
