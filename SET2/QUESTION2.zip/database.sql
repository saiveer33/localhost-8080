CREATE DATABASE userdb;
USE userdb;

CREATE TABLE users(
    email VARCHAR(50),
    password VARCHAR(50)
);
